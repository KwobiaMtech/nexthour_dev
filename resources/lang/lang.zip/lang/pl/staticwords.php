<?php 
return array (
  'Pay' => 'Zapłacić',
  'pay_method' => 'z Twojej ulubionej metody płatności',
  'CheckoutWith' => 'Sprawdzić',
  'RecentlyAddedIn' => 'Ostatnio dodane w',
  'FeaturedIn' => 'Wystepować w',
  'Becauseyouwatched' => 'Ponieważ oglądałeś',
  'ContinueWatchingFor' => 'Kontynuuj obserwowanie',
  'in' => 'w',
  'LoadingMoreGenres' => 'Ładowanie więcej gatunków',
);