<?php 
return array (
  'Pay' => 'دفع',
  'pay_method' => 'من طريقة الدفع المفضلة لديك',
  'CheckoutWith' => 'تحقق من مع',
  'RecentlyAddedIn' => 'أضيف مؤخرا في',
  'FeaturedIn' => 'يعلن عنه في',
  'Becauseyouwatched' => 'لأنك شاهدت',
  'ContinueWatchingFor' => 'تابع مشاهدة ل',
  'in' => 'في',
  'LoadingMoreGenres' => 'تحميل المزيد من الأنواع',
);