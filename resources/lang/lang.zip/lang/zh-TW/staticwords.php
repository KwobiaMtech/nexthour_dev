<?php 
return array (
  'Pay' => '工資',
  'pay_method' => '從您最喜歡的付款方式',
  'CheckoutWith' => '結帳方式',
  'RecentlyAddedIn' => '最近加入',
  'FeaturedIn' => '精選於',
  'Becauseyouwatched' => '因為你看了',
  'ContinueWatchingFor' => '繼續關注',
  'in' => '在',
  'LoadingMoreGenres' => '載入更多類型',
);