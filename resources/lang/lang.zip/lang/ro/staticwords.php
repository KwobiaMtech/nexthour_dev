<?php 
return array (
  'Pay' => 'A plati',
  'pay_method' => 'din metoda dvs. de plată preferată',
  'CheckoutWith' => 'Finalizare cu',
  'RecentlyAddedIn' => 'Adăugat recent în',
  'FeaturedIn' => 'Prezentat în',
  'Becauseyouwatched' => 'Pentru că ai urmărit',
  'ContinueWatchingFor' => 'Continuați să urmăriți',
  'in' => 'în',
  'LoadingMoreGenres' => 'Se încarcă mai multe genuri',
);