<?php 
return array (
  'Pay' => 'pagare',
  'pay_method' => 'dal tuo metodo di pagamento preferito',
  'CheckoutWith' => 'Acquista con',
  'RecentlyAddedIn' => 'Aggiunti di recente in',
  'FeaturedIn' => 'In primo piano in',
  'Becauseyouwatched' => 'Perché hai guardato',
  'ContinueWatchingFor' => 'Continua a guardare per',
  'in' => 'nel',
  'LoadingMoreGenres' => 'Caricamento di più generi',
);