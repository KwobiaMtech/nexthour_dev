<?php 
return array (
  'Pay' => 'Payer',
  'pay_method' => 'à partir de votre mode de paiement préféré',
  'CheckoutWith' => 'Vérifier avec',
  'RecentlyAddedIn' => 'Récemment ajouté dans',
  'FeaturedIn' => 'En vedette dans',
  'Becauseyouwatched' => 'Parce que tu as regardé',
  'ContinueWatchingFor' => 'Continuez à surveiller',
  'in' => 'dans',
  'LoadingMoreGenres' => 'Chargement de plus de genres',
);