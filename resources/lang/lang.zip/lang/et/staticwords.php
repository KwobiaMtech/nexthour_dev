<?php 
return array (
  'Pay' => 'Maksma',
  'pay_method' => 'oma lemmikmakseviisist',
  'CheckoutWith' => 'Kassa koos',
  'RecentlyAddedIn' => 'Viimati lisatud sisse',
  'FeaturedIn' => 'Esiletõstetud',
  'Becauseyouwatched' => 'Sest sa vaatasid',
  'ContinueWatchingFor' => 'Jätkake jälgimist',
  'in' => 'sisse',
  'LoadingMoreGenres' => 'Rohkem žanre laaditakse',
);