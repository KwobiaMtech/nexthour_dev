<?php 
return array (
  'Pay' => 'Pay',
  'pay_method' => 'from your favourite payment method',
  'CheckoutWith' => 'Checkout With',
  'RecentlyAddedIn' => 'Recently Added in',
  'FeaturedIn' => 'Featured in',
  'Becauseyouwatched' => 'Because you watched',
  'ContinueWatchingFor' => 'Continue Watching For',
  'in' => 'in',
  'LoadingMoreGenres' => 'Loading More Genres',
);