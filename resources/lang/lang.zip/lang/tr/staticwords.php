<?php 
return array (
  'Pay' => 'Ödemek',
  'pay_method' => 'favori ödeme yönteminizden',
  'CheckoutWith' => 'Ödeme Yeri',
  'RecentlyAddedIn' => 'Son Eklenenler',
  'FeaturedIn' => 'Öne çıkan',
  'Becauseyouwatched' => 'Çünkü izledin',
  'ContinueWatchingFor' => 'İzlemeye Devam Et',
  'in' => 'içinde',
  'LoadingMoreGenres' => 'Daha Fazla Tür Yükleniyor',
);