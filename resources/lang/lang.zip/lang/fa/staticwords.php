<?php 
return array (
  'Pay' => 'پرداخت',
  'pay_method' => 'از روش پرداخت مورد علاقه خود',
  'CheckoutWith' => 'پرداخت با',
  'RecentlyAddedIn' => 'اخیراً وارد شده است',
  'FeaturedIn' => 'برجسته در',
  'Becauseyouwatched' => 'چون تماشا کردی',
  'ContinueWatchingFor' => 'به تماشای ادامه دهید',
  'in' => 'که در',
  'LoadingMoreGenres' => 'بارگیری ژانرهای بیشتر',
);