<?php 
return array (
  'Pay' => 'Betalen',
  'pay_method' => 'via uw favoriete betaalmethode',
  'CheckoutWith' => 'Afrekenen met',
  'RecentlyAddedIn' => 'Recent toegevoegd',
  'FeaturedIn' => 'Aanbevolen in',
  'Becauseyouwatched' => 'Omdat je hebt gekeken',
  'ContinueWatchingFor' => 'Blijf kijken voor',
  'in' => 'in',
  'LoadingMoreGenres' => 'Meer genres laden',
);