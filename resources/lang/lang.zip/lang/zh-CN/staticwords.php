<?php 
return array (
  'Pay' => '工资',
  'pay_method' => '从您最喜欢的付款方式',
  'CheckoutWith' => '结帐方式',
  'RecentlyAddedIn' => '最近加入',
  'FeaturedIn' => '精选于',
  'Becauseyouwatched' => '因为你看了',
  'ContinueWatchingFor' => '继续关注',
  'in' => '在',
  'LoadingMoreGenres' => '载入更多类型',
);