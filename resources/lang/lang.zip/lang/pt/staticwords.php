<?php 
return array (
  'Pay' => 'Pagar',
  'pay_method' => 'do seu método de pagamento favorito',
  'CheckoutWith' => 'Checkout com',
  'RecentlyAddedIn' => 'Adicionado recentemente em',
  'FeaturedIn' => 'Destaque em',
  'Becauseyouwatched' => 'Porque você assistiu',
  'ContinueWatchingFor' => 'Continue assistindo',
  'in' => 'em',
  'LoadingMoreGenres' => 'Carregando mais gêneros',
);