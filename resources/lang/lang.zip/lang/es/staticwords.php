<?php 
return array (
  'Pay' => 'Pagar',
  'pay_method' => 'de tu método de pago favorito',
  'CheckoutWith' => 'Pagar con',
  'RecentlyAddedIn' => 'Recientemente agregado en',
  'FeaturedIn' => 'Presentado en',
  'Becauseyouwatched' => 'Porque viste',
  'ContinueWatchingFor' => 'Continuar observando',
  'in' => 'en',
  'LoadingMoreGenres' => 'Cargando más géneros',
);