<?php 
return array (
  'Pay' => 'वेतन',
  'pay_method' => 'अपने पसंदीदा भुगतान विधि से',
  'CheckoutWith' => 'के साथ चेकआउट करें',
  'RecentlyAddedIn' => 'हाल में जोड़ा गया',
  'FeaturedIn' => 'में प्रस्तुत',
  'Becauseyouwatched' => 'क्योंकि तुमने देखा',
  'ContinueWatchingFor' => 'देखना जारी रखें',
  'in' => 'में',
  'LoadingMoreGenres' => 'अधिक शैलियों लोड हो रहा है',
);