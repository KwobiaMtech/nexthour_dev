<?php 
return array (
  'Pay' => 'Zahlen',
  'pay_method' => 'von Ihrer bevorzugten Zahlungsmethode',
  'CheckoutWith' => 'Kasse mit',
  'RecentlyAddedIn' => 'Kürzlich hinzugefügt in',
  'FeaturedIn' => 'Abgebildet sein in; charakterisiert in',
  'Becauseyouwatched' => 'Weil du zugesehen hast',
  'ContinueWatchingFor' => 'Achten Sie weiter auf',
  'in' => 'im',
  'LoadingMoreGenres' => 'Weitere Genres laden',
);