<?php 
return array (
  'Pay' => 'Оплатить',
  'pay_method' => 'от вашего любимого способа оплаты',
  'CheckoutWith' => 'Оформить заказ с',
  'RecentlyAddedIn' => 'Недавно добавлено в',
  'FeaturedIn' => 'Показанный в',
  'Becauseyouwatched' => 'Потому что вы смотрели',
  'ContinueWatchingFor' => 'Продолжайте наблюдать за',
  'in' => 'в',
  'LoadingMoreGenres' => 'Загрузка больше жанров',
);